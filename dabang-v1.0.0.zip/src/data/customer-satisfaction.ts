export const customerSatisfaction = {
  'last month': [120, 132, 101, 134, 90, 230, 210],
  'this month': [220, 182, 191, 234, 290, 330, 310],
};
