export const totalRevenue = {
  'Online Sales': [14, 18, 6, 17, 12, 16, 22],
  'Offline Sales': [12, 11, 23, 6, 11, 14, 11],
};
