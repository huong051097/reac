export const volumeVsService = {
  volume: [160, 79, 102, 300, 84, 160, 243],
  services: [278, 289, 236, 78, 341, 236, 261],
};
