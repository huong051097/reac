export default [
  '0px 4px 20px 0px rgba(238, 238, 238, 0.5)',
  '0px 1px 1px 0px rgba(0, 0, 0, 0.03), 2px 2px 10px 0px rgba(0, 0, 0, 0.09)',
  '0px 0.286px 1.134px 0px rgba(0, 0, 0, 0.02), 0px 1.36px 2.867px 0px rgba(0, 0, 0, 0.03), 1px 3.92px 5.79px 0px rgba(0, 0, 0, 0.04), 2px 9px 11px 0px rgba(0, 0, 0, 0.04)',
];
